'use strict';

/* Filters */

var articleFilters = angular.module('articleFilters', []);
